from random import choices
from termcolor import colored
chances = {0: 0.6125, 1: 0.15, 2: 0.1, 3: 0.075, 5: 0.04, 10: 0.0225}


def slot():
    return choices(list(chances.keys()), weights=list(chances.values()))[0]


if __name__ == "__main__":
    invest, bets, hist = 1000, 0, 0
    while True:
        print(f"${invest}")
        bets += 1
        res = slot()
        bet = 100
        invest += bet * (res - 1)
        if res == 0:
            hist += 1
        else:
            hist = 0
        print(colored(f"Won ${res * bet}!" if res > 0 else "Lost it all.", "green" if res > 0 else "red"))
        if hist == 3:
            print("Lost three times in a row.")
            print(f"Survived {bets} bets.")
            break
