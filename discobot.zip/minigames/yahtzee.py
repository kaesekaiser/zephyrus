from random import randrange


class Yahtzee:
    cats = ["Aces", "Twos", "Threes", "Fours", "Fives", "Sixes", "Bonus", "Three of a Kind", "Four of a Kind", "Full House",
            "Small Straight", "Large Straight", "Yahtzee", "Chance"]

    def __init__(self, players):
        self.scores = {i.id: {g: "-" for g in self.cats} for i in players}

    def getscores(self, roll, id):
        cont, st = [roll.count(roll[g]) for g in range(5)], set(roll)
        r = {"Aces": roll.count(1), "Twos": 2 * roll.count(2), "Threes": 3 * roll.count(3), "Fours": 4 * roll.count(4),
             "Fives": 5 * roll.count(5), "Sixes": 6 * roll.count(6), "Three of a Kind": sum(roll) if 3 in cont else 0,
             "Four of a Kind": sum(roll) if 4 in cont else 0, "Full House": 25 if 2 in cont and 3 in cont else 0,
             "Small Straight": 30 if {1, 2, 3, 4} <= st or {2, 3, 4, 5} <= st or {3, 4, 5, 6} <= st else 0,
             "Large Straight": 40 if {1, 2, 3, 4, 5} <= st or {2, 3, 4, 5, 6} <= st else 0,
             "Yahtzee": 50 if 5 in cont else 0}
        return {key: r[key] for key in self.cats if key != "Bonus" and self.scores[id][key] == "-"}

    def endscore(self, id):
        return sum(list(self.scores[id].values())) + (35 if sum([self.scores[id][i] for i in self.cats[:6]]) >= 63 else 0)


def roll(given):
    return [randrange(6) + 1 for i in range(5 - len(given))] + given
