from random import shuffle
from copy import deepcopy
cs = " ".join([" ".join([b + c for b in ["R", "G", "B", "Y"]])
               for c in ["1", "2", "3", "4", "5", "6", "7", "8", "9", "R", "S", "D"]]).split(" ")
cards = ["R0", "G0", "B0", "Y0"] + 2 * cs + ["WC", "WC", "WC", "WC", "DF", "DF", "DF", "DF"]
instructions = {"S": "The first player will lose a turn.",
                "R": "Play will begin going in reverse.",
                "D": "The first player will draw two cards and miss a turn.",
                "C": "The first player can play a card of any color.",
                "F": "Fuck. We're re-shuffling."}


def hands(p: int):
    if p > 15:
        return
    deck = deepcopy(cards)
    shuffle(deck)
    return [deck[i:7*p:p] for i in range(p)], deck[7*p:]
