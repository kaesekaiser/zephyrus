class Black:
    pass


class White:
    pass


class Contested:
    pass
