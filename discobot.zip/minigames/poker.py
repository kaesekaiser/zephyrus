from random import shuffle
from copy import deepcopy
suits, ranks = ["♠", "♥", "♣", "♦"], ["2", "3", "4", "5", "6", "7", "8", "9", "10", "J", "Q", "K", "A"]
suitdict = {"♠": ":spades:", "♥": ":hearts:", "♣": ":clubs:", "♦": ":diamonds:"}
rankdict = {"2": ":two:", "3": ":three:", "4": ":four:", "5": ":five:", "6": ":six:", "7": ":seven:", "8": ":eight:",
            "9": ":nine:", "10": ":keycap_ten:", "J": ":regional_indicator_j:", "Q": ":regional_indicator_q:",
            "K": ":regional_indicator_k:", "A": ":regional_indicator_a:"}
handnames = ["Royal Flush", "Straight Flush", "Four-of-a-Kind", "Full House", "Flush", "Straight", "Three-of-a-Kind",
             "Two Pairs", "One Pair", "Highest Card"]
handdescs = ["Ace, king, queen, jack, 10, all of the same suit.", "Five consecutive cards of the same suit.",
             "Four of any rank of card.", "Three of one card rank, and two of another.", "Five cards of the same suit.",
             "Five consecutive cards.", "Three of any rank of card.", "Two pairs of card ranks.",
             "One pair of card ranks.", "Ranks according to highest card in the hand."]


def cards():
    for s in suits:
        for r in ranks:
            yield r + s


def combos():
    for i in range(5):
        for j in range(i, 5):
            for k in range(j, 5):
                yield " ".join([str(i), str(j), str(k)])


class Card:
    def __init__(self, s):
        self.rank = s[0:-1]
        self.suit = s[-1]

    def __lt__(self, other):
        return True if ranks.index(self.rank) < ranks.index(other.rank) else False

    def __eq__(self, other):
        return True if ranks.index(self.rank) == ranks.index(other.rank) else False

    def __str__(self):
        return "[ **" + self.rank + suitdict[self.suit] + "** ]"


class Hand:
    def __init__(self, cards):
        self.cards = [Card(c) for c in cards]

    def insert(self, card):
        self.cards.append(Card(card))

    def scards(self, ascending=False):
        return sorted(self.cards, key=lambda c: ranks.index(c.rank), reverse=(not ascending))

    def royalflush(self, high=False):
        return self.straightflush() and "A" in [c.rank for c in self.scards()] if high is False\
               else suits.index(self.cards[0].suit)

    def straightflush(self, high=False):
        return self.flush() and self.straight() if high is False else self.highest()

    def fourofakind(self, high=False):
        return 4 in [[c.rank for c in self.scards()].count(self.scards()[g].rank) for g in range(5)] if high is False\
               else [g for g in self.cards if [c.rank for c in self.scards()].count(g.rank) == 4][0].rank if\
               self.fourofakind() else None

    def fullhouse(self, high=False):
        return self.threeofakind() and self.onepair() if high is False else self.threeofakind(True)

    def flush(self, high=False):
        return [self.scards()[0].suit] * 5 == [c.suit for c in self.scards()] if high is False else self.highest()

    def straight(self, high=False):
        return ranks[ranks.index(self.scards(True)[0].rank):ranks.index(self.scards()[0].rank) + 1] ==\
               [c.rank for c in self.scards(True)] if high is False else self.highest()

    def threeofakind(self, high=False):
        return 3 in [[c.rank for c in self.scards()].count(self.scards()[g].rank) for g in range(5)] if high is False\
               else [g for g in self.cards if [c.rank for c in self.cards].count(g.rank) == 3][0].rank if\
               self.threeofakind() else None

    def twopair(self, high=False):
        return [[c.rank for c in self.scards()].count(self.scards()[g].rank) for g in range(5)].count(2) == 4\
               if high is False else\
               sorted([g.rank for g in self.cards if [c.rank for c in self.scards()].count(g.rank) == 2],
                      key=lambda r: ranks.index(r))[-1] if self.twopair() else None

    def onepair(self, high=False):
        return 2 in [[c.rank for c in self.scards()].count(self.scards()[g].rank) for g in range(5)] if high is False\
               else [g for g in self.cards if [c.rank for c in self.scards()].count(g.rank) == 2][0].rank\
               if self.onepair() else None

    def highest(self, high=False):
        return self.scards()[0].rank if high is False else self.scards()[1].rank

    def score(self, high=False):
        return [self.royalflush(high), self.straightflush(high), self.fourofakind(high), self.fullhouse(high),
                self.flush(high), self.straight(high), self.threeofakind(high), self.twopair(high), self.onepair(high),
                True if high is False else self.highest()]

    def txt(self, sort=False):
        return ",  ".join([str(c) for c in self.scards()]) if sort is True else ",  ".join([str(c) for c in self.cards])


def hands(n, size=5, p=list(cards())):
    if n * size > 52:
        raise ValueError("Dealer ran out of cards.")
    pool = deepcopy(p)
    shuffle(pool)
    return [Hand(pool[size * i:size * (i + 1)]) for i in range(n)], pool


def showdown(hands: list):
    return sorted(sorted(sorted(sorted(sorted(sorted(sorted(
        [(hands[g].score().index(True), hands[g].score(True)[hands[g].score().index(True)], hands[g].scards()[0].rank,
          hands[g].scards()[1].rank, hands[g].scards()[2].rank, hands[g].scards()[3].rank, hands[g].scards()[4].rank, g)
         for g in range(len(hands))], key=lambda c: ranks.index(c[6]), reverse=True),
        key=lambda c: ranks.index(c[5]), reverse=True), key=lambda c: ranks.index(c[4]), reverse=True),
        key=lambda c: ranks.index(c[3]), reverse=True), key=lambda c: ranks.index(c[2]), reverse=True),
        key=lambda c: ranks.index(c[1]), reverse=True), key=lambda c: c[0])


samples = [Hand(["A♠", "K♠", "Q♠", "J♠", "10♠"]).txt(), Hand(["8♥", "7♥", "6♥", "5♥", "4♥"]).txt(),
           Hand(["Q♠", "Q♥", "Q♣", "Q♦", "7♥"]).txt(), Hand(["J♥", "J♦", "J♣", "4♦", "4♥"]).txt(),
           Hand(["3♣", "7♣", "10♣", "6♣", "Q♣"]).txt(), Hand(["10♦", "9♦", "8♥", "7♣", "6♠"]).txt(),
           Hand(["9♦", "9♠", "9♥", "J♣", "5♣"]).txt(), Hand(["K♥", "K♦", "10♦", "10♠", "8♣"]).txt(),
           Hand(["Q♠", "Q♦", "8♥", "3♠", "4♥"]).txt(), Hand(["A♦", "J♣", "10♥", "7♣", "2♠"]).txt()]
