from utilities import words as wr, dict as dc


for i in wr.wordList:
    dic = dc.DictParser()
    try:
        dic.feed(dc.readurl(dc.deflink.format(i.lower())))
    except dc.HTTPError as h:
        print(i)
        print(h)
    else:
        if len(dic.definition) < 3:
            print(i)
