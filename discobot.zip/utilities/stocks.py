import urllib.request as req
from html.parser import HTMLParser
from urllib.error import HTTPError
quote_url = "https://finance.yahoo.com/quote/{}?ltr=1"


class StockParser(HTMLParser):
    def __init__(self):
        self.data = {}
        self.raw = ""
        self.printing = False
        super().__init__()

    def handle_data(self, data):
        if '"regularMarketPrice":{"raw":' in data:
            self.raw = data
            price = data.find('"regularMarketPrice":{"raw":')
            price2 = data.find("}", price)
            self.data["price"] = data[price:price2].split(":")[-1][1:-1]
            change = data.find('"regularMarketChange":{"raw":')
            change2 = data.find("}", change)
            self.data["priceChange"] = data[change:change2].split(":")[-1][1:-1]
            per = data.find('"regularMarketChangePercent":{"raw":')
            per2 = data.find("}", per)
            self.data["priceChangePercent"] = data[per:per2].split(":")[-1][1:-2]
            name = data.find('"shortName":')
            name2 = data.find(",\"", name)
            self.data["name"] = data[name:name2].split(":")[-1][1:-1]
            ticker = data.find('"symbol":')
            ticker2 = data.find(",", ticker)
            self.data["ticker"] = data[ticker:ticker2].split(":")[-1][1:-1]


def valid(t):
    return quote(t)["name"] != "10-Yr Bond"


def quote(t):
    def commfloat(s):
        return float("".join([c for c in s if c != ","]))

    stox, ret = StockParser(), {}
    stox.feed(str(req.urlopen(quote_url.format(t)).read()))
    if __name__ == "__main__":
        print(stox.raw)
    ret["price"] = commfloat(stox.data["price"])
    ret["change"] = float(stox.data["priceChange"])
    ret["perchange"] = float(stox.data["priceChangePercent"])
    ret["name"] = stox.data["name"]
    ret["ticker"] = stox.data["ticker"]
    return ret


def aps(n):
    return "+{}".format(n) if n >= 0 else str(n)


if __name__ == "__main__":
    print(quote("^GSPC"))
