from copy import deepcopy as copy


vowels = "eēiaāou"
mirrors = {"e": "ā", "ē": "o", "i": "u"}
mirrors = {**mirrors, **{j: g for g, j in mirrors.items()}}
'''numbers = {
    True: {
        "h": {1: "e", 2: "es", 3: "em"},
        "nh": {1: "ē|i", 2: "ēs", 3: "ēm"},
        "ab": {1: "i", 2: "is", 3: "im"}
    },
    False: {
        "h": {1: "ā|o", 2: "ās", 3: "ām"},
        "nh": {1: "o|u", 2: "os", 3: "om"},
        "ab": {1: "u", 2: "us", 3: "um"}
    }
}'''


def mirror(st: str):
    s = copy(st)
    for i in vowels[:3]:
        s = s.replace(i, mirrors[i])
        print(s)
    if s != st:
        return s
    else:
        for i in vowels[4:]:
            s = s.replace(i, mirrors[i])
        return s


class Case:
    def __init__(self, name: str, gloss: str, back: str, front: str):
        self.name = name
        self.gloss = gloss.upper()
        self.consonant = [back, front]
        self.structure = back.replace("A", "-").replace("o", "-").replace("u", "-")


cases = {
    "morphosyntactic": [
        Case("nominative", "NOM", "", ""), Case("accusative", "ACC", "d", "d"), Case("dative", "DAT", "v", "v"),
        Case("vocative", "VOC", "dh", "dh")
    ],
    "genitive": [
        Case("attributive", "ATTR", "yAn", "yen"), Case("compositional", "COMPOS", "tth", "tth"),
        Case("partitive", "PTV", "ts", "ts"), Case("possessive", "POSS", "k", "k"),
        Case("productive", "PROD", "run", "rin")
    ],
    "functional": [
        Case("abessive", "ABE", "zur", "zir"), Case("comitative", "COMIT", "q", "q"),
        Case("comparative", "COMPAR", "qAl", "qel"), Case("essive", "ESS", "bAz", "bez"),
        Case("exceptive", "EXC", "xur", "xir"), Case("instrumental", "INST", "ron", "rEn"),
        Case("semblative", "SEMBL", "ng", "ng")
    ],
    "instructional": [
        Case("aversive", "AVERS", "cAn", "cen"), Case("benefactive", "BENE", "hAb", "heb"),
        Case("causative", "CAUS", "x", "x"), Case("distributive", "DISTRIB", "thAn", "then"),
        Case("purposive", "PUR", "pow", "pEw"),
    ],
    "temporal": [
        Case("allapsive", "ALLAP", "wAt", "wet"), Case("concursive", "CONC", "hlAt", "hlet"),
        Case("elapsive", "ELAP", "gAt", "get")
    ],
    "spatial": [
        Case("ablative", "ABL", "mAj", "mej"), Case("adessive", "ADE", "hlAj", "hlej"),
        Case("antessive", "ANTE", "xAj", "xej"), Case("apudessive", "APUD", "ngAj", "ngej"),
        Case("inessive", "INE", "cAj", "cej"), Case("postessive", "POST", "nAj", "nej"),
        Case("subessive", "SUBE", "rAj", "rej"), Case("superessive", "SUPERE", "dAj", "dej")
    ],
    "range": [
        Case("egressive", "EGRE", "Non", "NEn"), Case("intrative", "INTR", "thun", "thin"),
        Case("terminative", "TERM", "gAl", "gel")
    ],
}


class Stem:
    def __init__(self, stem: str):
        self.stem = stem
        self.firstVowel = [g for g in stem if g in vowels][0]
        self.front = self.firstVowel in vowels[:3]

    def decline(self, case: Case, number: int):
        ret = self.stem + case.consonant[self.front]
        ret += ("a" if ret[-1] not in vowels and number > 1 else "") + {1: "", 2: "s", 3: "m"}[number]
        return ret.replace("A", "ā").replace("E", "ē").replace("N", "ñ")


if __name__ == "__main__":
    stone = Stem("nāma")
    apple = Stem("qeni")
    for gor in cases:
        print(f"! colspan=4 | <small>{gor.upper()}</small>\n|-")
        for cas in cases[gor]:
            print(f"! [[Narahlena/Noun cases/{cas.name.capitalize()}|{cas.name.capitalize()}]]<br>"
                  f"<small>{cas.gloss}</small>")
            for number in range(1, 4):
                print(f"| {stone.decline(cas, number)}<br>{apple.decline(cas, number)}")
            print("|-")
