movedict = {  # cap-name, power, accuracy, attributes
    "slash": ("Slash", 3, 90, []),
    "fuck": ("Fuck", 5, 70, ["fire"]),
    "bash": ("Bash", 3, 100, []),
    "stab": ("Stab", 3, 80, []),
    "plop": ("Plop", 1, 75, []),
    "stomp": ("Stomp", 4, 65, []),
    "magnet": ("Magnet Bomb", 3, 1000, ["electric"]),
    "icestab": ("Ice Spear", 4, 85, ["ice"]),
    "recover": ("Recover", 5, 60, ["heal"]),
    "shield": ("Shield", 1, 100, ["shield"])
}


weakness = {"fire": "ice", "ice": "fire", "electric": "poison", "poison": "electric"}


class Move:
    def __init__(self, move):
        d = movedict[move] if type(move) == str else move
        self.name = d[0]
        self.power = d[1]
        self.acc = d[2]
        self.attrs = d[3]
