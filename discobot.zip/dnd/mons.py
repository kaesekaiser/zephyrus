from dnd.moves import *


class Mon:
    def __init__(self, breed, moves, delta=0):
        d = breedDict[breed] if type(breed) == str else breed
        self.breed = d[0]
        self.hp = d[1]
        self.hpc = self.hp - delta
        self.dex = d[2]
        self.attrs = d[3]
        moves = [Move(m) for m in moves]
        self.moves = {m.name.lower(): m for m in moves}
        self.mName = None
        self.index = None
        self.shield = False

    def __str__(self):
        return " | ".join((self.breed, f"{self.hpc}/{self.hp} HP"))


class Player(Mon):
    def __init__(self, stats, moves):
        super().__init__(stats, moves)
        self.inv = []
        self.bp = stats[4]


breedDict = {  # name, hp, dex, attributes
    "blob": ("Flobbo", 2, 1, []),
    "boss1": ("Firstboss", 30, 5, ["ice"])
}

samplePlayer = Player(("Zeph", 10, 2, [], 5), ["slash", "shield", "icestab"])
