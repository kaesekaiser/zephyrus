import random
from copy import deepcopy
from dnd.mons import Player, samplePlayer


def tsum(*args):
    return tuple(sum([l[i] for l in args]) for i in range(len(args[0])))


def tmod(t, n):
    return tuple(i % n for i in t)


def rect(size: tuple):
    for i in range(size[0]):
        for j in range(size[1]):
            for k in range(size[2]):
                yield i, j, k


def pyramidal(size: int):
    for k in range(size):
        for i in range(k, 2 * size - 1 - k):
            for j in range(k, 2 * size - 1 - k):
                yield i, j, k


def petronas(size: int):
    for k in range(size):
        for i in range(9):
            for j in range(3):
                if i < 3 or i > 5 or ((size - k) % 4 == 1 and k != 0 and j == 1):
                    yield i, j, k


def cylindrical(size: tuple):
    for r in range(size[1]):
        for t in range(size[0] * 2 ** r):
            for k in range(size[2]):
                yield t, r, k


def conical(size: tuple):
    for k in range(size[2]):
        for r in range(size[1]):
            if r < size[1] * (1 - k / size[2]):
                for t in range(size[0] * 2 ** r):
                    yield t, r, k


def hexagonal(size: tuple):
    for i in range(2 * size[0] - 1):
        for j in range(2 * size[0] - 1):
            if abs(i - j) < size[0]:
                for k in range(size[1]):
                    yield i, j, k


def four(size: tuple):
    for i in range(size[0]):
        for j in range(size[1]):
            for k in range(size[2]):
                for l in range(size[3]):
                    yield i, j, k, l


def damned(size: int):
    for k in range(4):
        for i in range(3 * size):
            for j in range(3 * size):
                if i < size:
                    yield i, j, k
                elif i >= size * 2 and k in [1, 2]:
                    if j < size * 2 and k == 2:
                        yield i, j, k
                    if k == 1:
                        yield i, j, k
                elif k == 0:
                    if j < size:
                        yield i, j, k


def hexatronas(size: int):
    for i in range(9):
        for j in range(3):
            for k in range(size):
                if j == 0:
                    if i in [0, 1, 6, 7]:
                        yield i, j, k
                elif j == 1:
                    if (size - k) % 4 == 1 and k != 0:
                        yield i, j, k
                    elif j in [0, 1, 2, 6, 7, 8]:
                        yield i, j, k
                elif j == 2:
                    if i in [1, 2, 7, 8]:
                        yield i, j, k


shapes = [rect, pyramidal, petronas, cylindrical, conical, hexagonal, four, damned, hexatronas]
shapes = {func.__name__: func for func in shapes}


def doorcheck(shape):
    layout, size = shape
    return (lambda c: c[2] == 0, lambda c: c[2] == size - 1) if layout == "pyramidal" else\
           (lambda c: c[2] == 0 and (c[0] == 1 or (c[1] == 1 and c[0] < 3)),
            lambda c: c[2] == 0 and (c[0] == 7 or (c[1] == 1 and c[0] > 5))) if layout == "petronas" else\
           (lambda c: c[:2] in ((0, 0), (0, size[0] - 1), (size[0] - 1, 0), (size[0] - 1, 2 * size[0] - 1),
                                (2 * size[0] - 1, size[0] - 1), (2 * size[0] - 1, 2 * size[0] - 1)),
            lambda c: c[:2] in ((0, 0), (0, size[0] - 1), (size[0] - 1, 0), (size[0] - 1, 2 * size[0] - 1),
                                (2 * size[0] - 1, size[0] - 1), (2 * size[0] - 1, 2 * size[0] - 1)))\
        if layout == "hexagonal" else (lambda c: c[3] == 0, lambda c: True) if layout == "four" else\
           (lambda c: c[2] == 0 and c[0] < 3, lambda c: c[2] == 0 and c[0] > 5) if layout == "hexatronas" else\
           (lambda c: c[2] == 3, lambda c: c[2] == 2 and c[0] > size) if layout == "nukasaan" else\
           (lambda c: True, lambda c: True)


class Maze:
    dirs = {"n": (0, 1, 0), "s": (0, -1, 0), "e": (1, 0, 0), "w": (-1, 0, 0), "u": (0, 0, 1), "d": (0, 0, -1)}
    names = {"n": "north", "s": "south", "e": "east", "w": "west", "u": "up", "d": "down"}
    cols = {"n": "red", "s": "blue", "e": "green", "w": "magenta", "u": "cyan", "d": "yellow"}

    def __init__(self, shape: tuple, explorer: Player, entrance=(0, 0, 0), lvl=1):
        self.doors, self.rooms, self.exit, self.boss, self.chests, self.bigchest, self.pos, self.explorer, self.shape =\
            {}, [], (), (), {}, (), entrance, explorer, shape
        self.lvl = lvl

    def setSpecials(self, entrance=None, boss=None):
        if entrance is not None:
            self.setExit(entrance)
        self.setBoss(boss)
        self.bigchest = random.choice([g for g in self.rooms if g not in self.exit and g not in self.boss])

    def setExit(self, entrance):
        self.exit = (entrance, random.choice([g for g in list(self.dirs.keys())[:4]
                                              if self.move(entrance, g) not in self.rooms]))
        self.pos = self.exit[0]

    def setBoss(self, boss=None):
        if boss is None:
            boss = random.choice([g for g in self.rooms if self.edge(g) and g not in self.exit
                                  and (doorcheck(self.shape)[1])(g)])
        self.boss = (boss, random.choice([g for g in list(self.dirs.keys())[:4]
                                     if self.move(boss, g) not in self.rooms]))

    def floor(self, room):
        return room[2] + (1 if room[2] >= self.exit[0][2] else 0) - self.exit[0][2]

    def exitlist(self, room):
        return f"doors: **{', '.join([g.upper() for g in self.doors[room] if g in self.dirs])}**" \
               f"\nfloor: **{'F' if room[2] >= self.exit[0][2] else 'B'}{abs(self.floor(room))}**" +\
               (f"\nThe exit is to the **{self.names[self.exit[1]]}.**" if room in self.exit else
                f"\nThe boss is to the **{self.names[self.boss[1]]}.**" if room in self.boss else
                "\nThe big chest is in this room." if room == self.bigchest else
                "\nThere is a small chest in this room." if room in self.chests else "")

    def edge(self, room):
        return False in [g in self.rooms for g in [self.move(room, d) for d in list(self.dirs.keys())[:4]]]

    def move(self, room, dir):
        return tsum(room, self.dirs[dir])


class PrimMaze(Maze):  # uses randomly weighted Prim's algorithm to generate maze on square grid
    def __init__(self, shape, explorer: Player, entrance=None):
        super().__init__(shape, explorer, entrance)
        maze, adjacent, walls = {}, {}, []
        self.rooms = list(shapes[shape[0]](shape[1]))

        for i in self.rooms:
            maze[i] = 0
            ts = [self.move(i, g) for g in self.dirs]
            ls = [g for g in ts if g in self.rooms]
            adjacent[i] = set(ls)
            for p in ls:
                if {i, p} not in walls:
                    walls.append({i, p})

        if entrance is None:
            entrance = random.choice([g for g in maze if self.edge(g) and doorcheck(self.shape)[0](g)])
        self.setExit(entrance)
        maze[entrance] = 1
        mazejacent, blocked = deepcopy(adjacent[entrance]), {tuple(w): 0 for w in walls}

        while len(mazejacent) > 0:
            new = random.choice(list(mazejacent))
            conn = random.choice([g for g in adjacent[new] if maze[g] == 1])
            blocked[tuple({new, conn})] = 1
            maze[new] = 1
            mazejacent = {g for g in mazejacent | adjacent[new] if maze[g] == 0}

        self.doors = {room: [] for room in self.rooms}
        for i in self.rooms:
            for p in self.dirs:
                if blocked.get(tuple({i, self.move(i, p)}), 0) == 1:
                    self.doors[i].append(p)

        self.setSpecials()


class RingMaze(Maze):
    dirs = {"i": (0, -1, 0), "o": (0, 1, 0), "c": (1, 0, 0), "w": (-1, 0, 0), "u": (0, 0, 1), "d": (0, 0, -1)}
    names = {"i": "inward", "o": "outward", "c": "counterclockwise", "w": "clockwise", "u": "upward", "d": "downward"}

    def move(self, room, dir):
        return tsum(room, self.dirs[dir]) if dir in "ud" else\
            (round(room[0] * 2 ** self.dirs[dir][1], 1), room[1] + self.dirs[dir][1], room[2]) if dir in "io" else\
            ((room[0] + self.dirs[dir][0]) % (self.shape[1][0] * 2 ** room[1]), room[1], room[2])

    def edge(self, room):
        return self.move(room, "o") not in self.rooms

    def __init__(self, shape, explorer: Player, entrance=None):
        super().__init__(shape, explorer, entrance)
        maze, adjacent, walls = {}, {}, []
        self.rooms = list(shapes[shape[0]](shape[1]))

        for i in self.rooms:
            maze[i] = 0
            ts = [self.move(i, g) for g in self.dirs]
            ls = [g for g in ts if g in self.rooms]
            adjacent[i] = {tuple(int(g) for g in l) for l in ls}
            for p in ls:
                if {i, p} not in walls:
                    walls.append({i, p})

        if entrance is None:
            entrance = random.choice([g for g in maze if self.edge(g) and doorcheck(self.shape)[0](g)])
        self.setExit(entrance)
        maze[entrance] = 1
        mazejacent, blocked = deepcopy(adjacent[entrance]), {tuple(w): 0 for w in walls}

        while len(mazejacent) > 0:
            new = random.choice(list(mazejacent))
            conn = random.choice([g for g in adjacent[new] if maze[g] == 1])
            blocked[tuple({new, conn})] = 1
            maze[new] = 1
            mazejacent = {g for g in mazejacent | adjacent[new] if maze[g] == 0}

        self.doors = {room: [] for room in self.rooms}
        for i in self.rooms:
            for p in self.dirs:
                if blocked.get(tuple({i, self.move(i, p)}), 0) == 1:
                    self.doors[i].append(p)

        self.setSpecials()

    def exitlist(self, room):
        return f"doors: **{', '.join([g.upper() for g in self.doors[room] if g in self.dirs])}**" \
               f"\nfloor: **{'F' if room[2] >= self.exit[0][2] else 'B'}{abs(self.floor(room))}**" + \
               (f"\nThe exit is **{self.names[self.exit[1]]}.**" if room in self.exit else
                f"\nThe boss is **{self.names[self.boss[1]]}.**" if room in self.boss else
                "\nThe big chest is in this room." if room == self.bigchest else
                "\nThere is a small chest in this room." if room in self.chests else "")

    def setExit(self, entrance):
        self.exit = (entrance, "o")
        self.pos = self.exit[0]

    def setBoss(self, boss=None):
        if boss is None:
            boss = random.choice([g for g in self.rooms if self.edge(g) and g not in self.exit
                                  and (doorcheck(self.shape)[1])(g)])
        self.boss = (boss, "o")


class HexMaze(PrimMaze):
    dirs = {"nw": (0, 1, 0), "ne": (1, 1, 0), "e": (1, 0, 0), "se": (0, -1, 0), "sw": (-1, -1, 0), "w": (-1, 0, 0),
            "u": (0, 0, 1), "d": (0, 0, -1)}
    names = {"nw": "northwest", "ne": "northeast", "e": "east", "se": "southeast", "sw": "southwest", "w": "west",
             "u": "up", "d": "down"}

    def edge(self, room):
        return False in [g in self.rooms for g in [self.move(room, d) for d in list(self.dirs.keys())[:6]]]

    def setExit(self, entrance):
        self.exit = (entrance, random.choice([g for g in list(self.dirs.keys())[:6]
                                              if self.move(entrance, g) not in self.rooms]))
        self.pos = self.exit[0]

    def setBoss(self, boss=None):
        if boss is None:
            boss = random.choice([g for g in self.rooms if self.edge(g) and g not in self.exit
                                  and (doorcheck(self.shape)[1])(g)])
        self.boss = (boss, random.choice([g for g in list(self.dirs.keys())[:6]
                                     if self.move(boss, g) not in self.rooms]))


class FourMaze(PrimMaze):
    dirs = {"n": (0, 1, 0, 0), "s": (0, -1, 0, 0), "e": (1, 0, 0, 0), "w": (-1, 0, 0, 0),
            "u": (0, 0, 1, 0), "d": (0, 0, -1, 0), "a": (0, 0, 0, 1), "k": (0, 0, 0, -1)}
    names = {"n": "north", "s": "south", "e": "east", "w": "west", "u": "up", "d": "down", "a": "ana", "k": "kata"}

    def exitlist(self, room):
        return f"doors: **{', '.join([g.upper() for g in self.doors[room] if g in self.dirs])}**" \
               f"\nfloor: **{'F' if room[2] >= self.exit[0][2] else 'B'}{abs(self.floor(room))}**" +\
               f"\nparallel: **{'P' if room[3] >= self.exit[0][3] else 'β'}{abs(self.parallel(room))}**" +\
               (f"\nThe exit is to the **{self.names[self.exit[1]]}.**" if room in self.exit else
                f"\nThe boss is to the **{self.names[self.boss[1]]}.**" if room in self.boss else
                "\nThe big chest is in this room." if room == self.bigchest else
                "\nThere is a small chest in this room." if room in self.chests else "")

    def parallel(self, room):
        return room[3] + (1 if room[3] >= self.exit[0][3] else 0) - self.exit[0][3]

